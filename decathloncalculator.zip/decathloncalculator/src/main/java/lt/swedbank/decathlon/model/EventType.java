package lt.swedbank.decathlon.model;

public enum EventType {
    TRACK, FIELD
}
