package lt.swedbank.decathlon.model;

public enum EventUnit {
    MINUTES, SECONDS, METERS, CENTIMETERS
}
